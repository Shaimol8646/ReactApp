import React from 'react';
import logo from './logo.svg';
import './App.css';
import TableWork from './tableComponent/table-component';
//import {TableComponent} from "./tableComponent/table-component";

function App() {
  return (
    <div className="App">
      {/* <header className="App-header">
       
      </header> <TableComponent/> */
      }
     <TableWork/>
    </div>
  );
}

export default App;
