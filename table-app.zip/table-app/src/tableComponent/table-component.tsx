import { Table } from 'antd';
import React from 'react';
export default class TableComponent extends React.Component{

// eslint-disable-next-line react/require-render-return
render(){

  const dataSource = [
    {
      key: '1',
      name: 'Ishow',
      age: 33,
      address: '20 Bethleham, Nazerath',
    },
    {
      key: '1',
      name: 'Ishow',
      age: 33,
      address: '20 Bethleham, Nazerath',
    },
    {
      key: '1',
      name: 'Ishow',
      age: 33,
      address: '20 Bethleham, Nazerath',
    },
  ];
  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      address: 'name',
    },  
    {
      title: 'Age',
      dataIndex: 'age',
      address: 'age',
    }, 
    {
      title: 'Address',
      dataIndex: 'address',
      address: 'Aadress',
    }, ];
 return <Table dataSource={dataSource} columns={columns}/>
}
componentDidMount(){
  const axios = require("axios");

const options = {
  method: 'GET',
  url: 'https://hub.dummyapis.com/employee?noofRecords=10&idStarts=1001/',
  headers: {
    'X-RapidAPI-Host': 'fairestdb.p.rapidapi.com',
    'X-RapidAPI-Key': 'SIGN-UP-FOR-KEY'
  }
};

axios.request(options).then(function (response: { data: any; }) {
	console.log(response.data);
}).catch(function (error: any) {
	console.error(error);
});
// fetch('https://hub.dummyapis.com/employee?noofRecords=10&idStarts=1001').
// then(response) => response.json())
// .then(booklist =>{this.setState({books:booklist})})

}
}