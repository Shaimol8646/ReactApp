import { Table } from 'antd';
import { useEffect,useState } from 'react';//what used for
import React from 'react';
import { EditOutlined, DeleteOutlined } from "@ant-design/icons";
import { setConstantValue } from 'typescript';
function TableWork(){//functiona nd class call difference
const[users,setUsers]= useState<User[]>([])
const [error,setError]=useState({})
const columns = [
  {
    title: 'Id',
    dataIndex: 'id',
    key: 'id',
  },  
  {
    title: 'FirstName',
    dataIndex: 'firstName',
    key: 'firstName',
  }, 
  {
    title: 'LastName',
    dataIndex: 'lastName',
    key: 'lastName',
  },
  {
    title: 'Email',
    dataIndex: 'email',
    key: 'email',
  },
  {
    title: 'ContactNumber',
    dataIndex: 'contactNumber',
    key: 'contactNumber',
  },
  {
    title: 'Age',
    dataIndex: 'age',
    key: 'age',
  },
  {
    title: 'Address',
    dataIndex: 'address',
    key: 'address',
  },
  {
title:"Actions",
render:(record: any)=>{//error record
 // render:()=>{
  return<>
  <EditOutlined/>
  <DeleteOutlined style={{color:"red",marginLeft:12}}/>
  </>
}}
];

interface User{
  id: number;
  firstName:String;
  lastName:String;
  email:String;
  contactNumber:number;
  age:number;
  address: String;
}
//creation function
  const onAddEmployee = () => {
    const randomNumber =  Math.random() * 1000;
    const newEmployee = {
      id: ,
      firstName: "",
      lastName: "",
      email: "",
      contactNumber: null,
      age: null,
      address: "",
    }
    setUsers(pre => {
        return [...pre, newEmployee]
      
      })
    
  // function setDataSource() {
  //   throw new Error('Function not implemented.');
  // }
  }

  //---delete function

// const onDeleteEmployee=(record: any)=>{
//   setDataSource(pre=>{
//           return pre.filter((Employee)=> Employee.id !== record.id);
//         })
//   }

// }
useEffect(()=>{//useEffect function?
  const axios = require("axios");

const options = {
  method: 'GET',
  url: 'https://hub.dummyapis.com/employee?noofRecords=10&idStarts=1001/',
  // headers: {
  //   'X-RapidAPI-Host': 'fairestdb.p.rapidapi.com',
  //   'X-RapidAPI-Key': 'SIGN-UP-FOR-KEY'
  // }
};

axios.request(options).then(function (response: { data: any; }) {
	console.log(response.data);
    setUsers(pre => {
      return [...pre, response.data]
    
    });
  
}).catch(function (error: any) {
	console.error(error);
});

},[])


//array means?
// const newEmployee = {
//   id: randomNumber,
//   firstName: "First Name" + randomNumber,
//   lastName: "Last Name" + randomNumber,
//   email: randomNumber+ "@gmail.com",
//   contactNumber: "",
//   age: "",
//   address: "Address"+ randomNumber,
// }
// setDataSource(pre => {
//   return [...pre, newEmployee]

// })
// }
return(
  <div className='App'>
    <div className='App-content'>
        <p>Click here to add a new Employee</p>
       <button onClick={onAddEmployee}>Add Employee</button>
      </div>
    <Table dataSource={users} columns={columns}/>
     </div>
);
}
export default TableWork;
//export default class TableComponent extends React.Component{


// render(){

//   const dataSource = [
//     {
//       key: '1',
//       id:'1001',
//       firstname: 'Ishow',
//       lastname:"Joseph",
//       age: 33,
//       email:"ishow@gmail.com",
//       contactnumber:"0987654321",
//       address: '20 Bethleham, Nazerath',
//     },
//     {
//       key: '1',
//       name: 'Ishow',
//       age: 33,
//       address: '20 Bethleham, Nazerath',
//     },
//     {
//       key: '1',
//       name: 'Ishow',
//       age: 33,
//       address: '20 Bethleham, Nazerath',
//     },
//   ];
  // const columns = [
  //   {
  //     title: 'Id',
  //     dataIndex: 'id',
  //     key: 'id',
  //   },  
  //   {
  //     title: 'FirstName',
  //     dataIndex: 'firstname',
  //     key: 'firstname',
  //   }, 
  //   {
  //     title: 'LastName',
  //     dataIndex: 'lastname',
  //     key: 'lastname',
  //   },
  //   {
  //     title: 'Email',
  //     dataIndex: 'email',
  //     key: 'email',
  //   },
  //   {
  //     title: 'ContactNumber',
  //     dataIndex: 'contactnumber',
  //     key: 'contactnumber',
  //   },
  //   {
  //     title: 'Age',
  //     dataIndex: 'age',
  //     key: 'age',
  //   },
  //   {
  //     title: 'Address',
  //     dataIndex: 'address',
  //     key: 'address',
  //   },
  // ];
//   const onAddEmployee=()=>{
//     // const randomNumber =  Math.random()=1000
//     const newEmployee = {
//       id: "" ,
//       name:"",
//       age: "",
//       email:"",
//       address: "",
//     }
//     setDataSource(pre=>{
//       return [...pre, newEmployee]
//     })}
//  return (
//    <div className="tableDiv">
//       <div className='App-content'>
//        <p>Click here to add a new Employee</p>
//        <button onClick={onAddEmployee}>Add Employee</button>
//        </div>
//      <Table dataSource={dataSource} columns={columns}/>
//    </div>
//  );
// }
// componentDidMount(){
//   const axios = require("axios");

// const options = {
//   method: 'GET',
//   url: 'https://hub.dummyapis.com/employee?noofRecords=10&idStarts=1001/',
//   headers: {
//     'X-RapidAPI-Host': 'fairestdb.p.rapidapi.com',
//     'X-RapidAPI-Key': 'SIGN-UP-FOR-KEY'
//   }
// };

// axios.request(options).then(function (response: { data: any; }) {
// 	console.log(response.data);
//   const getEmployee=()=>{
//     // const randomNumber =  Math.random()=1000
//     const newEmployee = {
//       id: response.data.id ,
//       name:response.data.firstName ,
//       age: response.data.age,
//       email:response.data.email,
//       address: response.data.address,
//     }
//     setDataSource((pre)=>{
//       return [...pre, newEmployee];
//     });
//   };
  
// }).catch(function (error: any) {
// 	console.error(error);
// });

// // fetch('https://hub.dummyapis.com/employee?noofRecords=10&idStarts=1001').
// // then(response) => response.json())
// // .then(booklist =>{this.setState({books:booklist})})

// }
// }


